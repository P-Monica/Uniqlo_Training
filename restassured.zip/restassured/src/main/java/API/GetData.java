package API;

import org.apache.http.HttpResponse;
import org.json.simple.JSONObject;
import org.junit.runner.Request;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class GetData {

	@Test
	public void getmethod()
	{  
		// RestAssured is a predefined class
		  RestAssured.baseURI="https://postman-echo.com";
		  
		// RequestSpecification is a predefined class
		 // httpRequest is a request object used to send request so we created httpRequest object for RequestSpecification 
		  RequestSpecification httpRequest = RestAssured.given();
		  
		  Response response = httpRequest.request(Method.GET,"?foo1=bar1&foo2=bar2");
		  System.out.println("Response "+response.asString());
		  
		  int statuscode=response.getStatusCode();
		 
	 
		
}
	
}