package API;

import org.apache.http.HttpResponse;
import org.json.simple.JSONObject;
import org.junit.runner.Request;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class GetData {
	ExtentReports report;
	ExtentTest logger;
	@Test
	public void getmethod()
	{  
		
		 RestAssured.baseURI="https://postman-echo.com";
		
		  report=new ExtentReports("E:\\Java_Workspace\\Automation Project\\restassured\\Report\\UniqloAPI.html");
		  logger=report.startTest("getmethod");
		  logger.log(LogStatus.INFO, "API started ");
		// RestAssured is a predefined class
		 
		  
		// RequestSpecification is a predefined class
		 // httpRequest is a request object used to send request so we created httpRequest object for RequestSpecification 
		  RequestSpecification httpRequest = RestAssured.given();
		  
		  Response response = httpRequest.request(Method.GET,"?foo1=bar1&foo2=bar2");
		  System.out.println("Response "+response.asString());
		  
		  int statuscode=response.getStatusCode();
		  Assert.assertEquals(statuscode,200); 
		  
			
}

	 @AfterMethod
	  public void tearDown(ITestResult result)
	  {

	  report.endTest(logger);
	  report.flush();
	   

	  }
	
}