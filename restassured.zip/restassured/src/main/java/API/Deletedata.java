package API;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Deletedata {
@Test
public void deletemethod() {
	//RestAssured.baseURI="https://postman-echo.com/delete";
	
    RequestSpecification httpRequest = RestAssured.given();

    Response response = httpRequest.delete("https://postman-echo.com/delete");
    System.out.println("Response "+response.asString());
     
    int statuscode=response.getStatusCode();
}
}
