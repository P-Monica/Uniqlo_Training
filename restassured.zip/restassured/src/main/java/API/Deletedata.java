package API;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class Deletedata {
	ExtentReports report;
	ExtentTest logger; 
@Test
public void deletemethod() {
		
	RestAssured.baseURI="https://postman-echo.com";
	report=new ExtentReports("E:\\Java_Workspace\\Automation Project\\restassured\\Report\\UniqloAPIDelete.html");
	  logger=report.startTest("postmethod");
	  logger.log(LogStatus.INFO, "API started ");
	RequestSpecification request = RestAssured.given();
	request.header("Content-Type","application/json");
    Response response = request.request(Method.DELETE,"/delete");
    int statusCode = response.getStatusCode();
    System.out.println("Status code = "+statusCode);
    Assert.assertEquals(statusCode, 200);
    System.out.println("Response time = "+response.getTime());
	  
	
}

@AfterMethod
  public void tearDown(ITestResult result)
  {

  report.endTest(logger);
  report.flush();
   

  }
}

