package API;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Putdata {
	ExtentReports report;
	ExtentTest logger;
	@Test
	public void putmethod() {
		
     RestAssured.baseURI="https://postman-echo.com";
     report=new ExtentReports("E:\\Java_Workspace\\Automation Project\\restassured\\Report\\UniqloAPIPut.html");
	  logger=report.startTest("putmethod");
	  logger.log(LogStatus.INFO, "API started ");
		 RequestSpecification request = RestAssured.given();
		 
		JSONObject requestparam=new JSONObject();
		
		requestparam.put("Firstname","Monica");
		requestparam.put("Lastname","Paranthaman");
		requestparam.put("City","Bangalore");
		
		//Add a header stating the request body is a JSON
		request.header("Content-Type","application/json");
		
		//Add the JSON to the body of the request
		request.body(requestparam.toJSONString());
		
		Response response =request.request(Method.DELETE,"/delete");
		
		//String responsebody=response.getBody().asString();
		int statuscode=response.statusCode();
		//System.out.println("Response body is" +responsebody);
		Assert.assertEquals(statuscode,200);

}

	@AfterMethod
	  public void tearDown(ITestResult result)
	  {

	  report.endTest(logger);
	  report.flush();
	   

	  }
}