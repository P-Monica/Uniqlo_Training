package API;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Putdata {

	@Test
	public void putmethod() {
		/*
		 * RestAssured.baseURI="https://postman-echo.com/put";
		 * 
		 * RequestSpecification request = RestAssured.given();
		 * 
		 * Response response = request.put("https://postman-echo.com/put");
		 * System.out.println("Response "+response.asString());
		 * 
		 * int statuscode=response.getStatusCode();
		 */
     // RestAssured.baseURI="https://postman-echo.com/put";
		 
		 RequestSpecification request = RestAssured.given();
		 
		JSONObject requestparam=new JSONObject();
		
		requestparam.put("Firstname","Monica");
		requestparam.put("Lastname","Paranthaman");
		requestparam.put("City","Bangalore");
		
		//Add a header stating the request body is a JSON
		request.header("Content-Type","application/json");
		
		//Add the JSON to the body of the request
		request.body(requestparam.toJSONString());
		
		Response response =request.put("https://postman-echo.com/put");
		
		//String responsebody=response.getBody().asString();
		int statuscode=response.statusCode();
		//System.out.println("Response body is" +responsebody);
		Assert.assertEquals(statuscode,200);

}
}