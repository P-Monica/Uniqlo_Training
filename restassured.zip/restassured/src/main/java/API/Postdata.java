package API;


import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Postdata {

	@Test
	public void postmethod() {
		
		 
		 RestAssured.baseURI="https://postman-echo.com/post";
		 
		 RequestSpecification request = RestAssured.given();
		 
		JSONObject requestparam=new JSONObject();
		
		requestparam.put("Firstname","Monica");
		requestparam.put("Lastname","Paranthaman");
		requestparam.put("City","Chennai");
		request.header("Content-Type","application/json");
		
		request.body(requestparam.toJSONString());
		
		Response response =request.request(Method.POST);
		
		String responsebody=response.getBody().asString();
		int statuscode=response.statusCode();
		System.out.println("Response body is" +responsebody);
		Assert.assertEquals(statuscode,200);
	}
}
